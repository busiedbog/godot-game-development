extends Area2D
var screensize = Vector2.ZERO

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Timer.start(randf_range(3, 8))


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_timer_timeout() -> void:
	$AnimatedSprite2D.frame = 0
	$AnimatedSprite2D.play()
