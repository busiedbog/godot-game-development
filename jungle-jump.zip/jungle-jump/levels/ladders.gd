extends Area2D

func _on_ladders_body_entered(body):
	body.is_on_ladder = true
	
func _on_ladders_body_exited(body):
	body.is_on_ladder = false
