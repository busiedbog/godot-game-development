extends Area2D
@export var speed = 1000
func start(_pos, _dir):
	position = _pos
	rotation = _dir.angle()
@export var damage = 15

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position += transform.x * speed * delta



func _on_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		body.shield -= damage
	queue_free()


func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	queue_free()
